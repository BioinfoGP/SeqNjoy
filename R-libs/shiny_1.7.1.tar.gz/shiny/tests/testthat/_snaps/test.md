# app template works with runTests

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-all/tests/shinytest.R
        - shinyAppTemplate-all/tests/testthat.R

---

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-app_shinytest/tests/shinytest.R

---

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-app_module_shinytest/tests/shinytest.R

---

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-app_testthat/tests/testthat.R

---

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-app_module_testthat/tests/testthat.R

---

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-app_rdir_testthat/tests/testthat.R

---

    Code
      out
    Output
      Shiny App Test Results
      * Success
        - shinyAppTemplate-app_module_rdir_testthat/tests/testthat.R

